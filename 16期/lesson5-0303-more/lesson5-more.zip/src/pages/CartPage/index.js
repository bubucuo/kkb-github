import React, {Component} from "react";

export default class CartPage extends Component {
  render() {
    return (
      <div>
        <h3>CartPage</h3>
      </div>
    );
  }
}
