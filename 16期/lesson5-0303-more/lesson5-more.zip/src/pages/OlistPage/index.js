import React, {Component} from "react";

export default class OlistPage extends Component {
  render() {
    return (
      <div>
        <h3>OlistPage</h3>
      </div>
    );
  }
}
